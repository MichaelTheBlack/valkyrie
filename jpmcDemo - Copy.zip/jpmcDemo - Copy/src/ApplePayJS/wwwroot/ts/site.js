var justEat;
(function (justEat) {
    var ApplePay = (function () {
        function ApplePay() {
            var _this = this;
            this.beginPayment = function (e) {
                e.preventDefault();
                var subtotal = $("#amount").val();
                var delivery = "0.01";
                var deliveryTotal = (parseFloat(subtotal) + parseFloat(delivery)).toString(10);
                var totalForCollection = {
                    label: _this.storeName,
                    amount: subtotal
                };
                var lineItemsForCollection = [
                    { label: "Subtotal", amount: subtotal, type: "final" }
                ];
                var totalForDelivery = {
                    label: _this.storeName,
                    amount: deliveryTotal
                };
                var lineItemsForDelivery = [
                    { label: "Subtotal", amount: subtotal, type: "final" },
                    { label: "Delivery", amount: delivery, type: "final" }
                ];
                var paymentRequest = _this.createPaymentRequest(delivery, lineItemsForDelivery, totalForDelivery);
                _this.session = new ApplePaySession(_this.applePayVersion, paymentRequest);
                _this.session.onvalidatemerchant = _this.onValidateMerchant;
                _this.session.onshippingmethodselected = function (event) {
                    var newTotal;
                    var newLineItems;
                    if (event.shippingMethod.identifier === "collection") {
                        newTotal = totalForCollection;
                        newLineItems = lineItemsForCollection;
                    }
                    else {
                        newTotal = totalForDelivery;
                        newLineItems = lineItemsForDelivery;
                    }
                    _this.session.completeShippingMethodSelection(ApplePaySession.STATUS_SUCCESS, newTotal, newLineItems);
                };
                _this.session.onpaymentauthorized = _this.onPaymentAuthorized;
                _this.session.begin();
            };
            this.createPaymentRequest = function (deliveryAmount, lineItems, total) {
                return {
                    countryCode: _this.countryCode,
                    currencyCode: _this.currencyCode,
                    merchantCapabilities: ["supports3DS", "supportsCredit", "supportsDebit"],
                    supportedNetworks: ["amex", "discover", "jcb", "masterCard", "privateLabel", "visa"],
                    lineItems: lineItems,
                    total: total,
                    requiredBillingContactFields: ["email", "name", "phone", "postalAddress"],
                    requiredShippingContactFields: ["email", "name", "phone", "postalAddress"],
                    shippingType: "delivery",
                    shippingMethods: [
                        { label: "Delivery", amount: deliveryAmount, identifier: "delivery", detail: "Delivery to you" },
                        { label: "Collection", amount: "0.00", identifier: "collection", detail: "Collect from the store" }
                    ]
                };
            };
            this.onPaymentAuthorized = function (event) {
                var token = event.payment.token;
                var paymentStatus = _this.captureFunds(token);
                if (paymentStatus === ApplePaySession.STATUS_SUCCESS) {
                    var billingContact = event.payment.billingContact;
                    var shippingContact = event.payment.shippingContact;
                    $(".card-name").text(event.payment.token.paymentMethod.displayName);
                    _this.updatePanel($("#billing-contact"), billingContact);
                    _this.updatePanel($("#shipping-contact"), shippingContact);
                    _this.session.completePayment(paymentStatus);
                    _this.showSuccess();
                }
                else {
                    _this.showError("Your payment could not be processed. Error code: " + paymentStatus + ".");
                }
            };
            this.onValidateMerchant = function (event) {
                var data = {
                    validationUrl: event.validationURL
                };
                var headers = _this.createValidationHeaders();
                var request = _this.createValidationRequest(data, headers);
                $.ajax(request).then(function (merchantSession) {
                    _this.session.completeMerchantValidation(merchantSession);
                });
            };
            this.createValidationRequest = function (data, headers) {
                return {
                    url: _this.validationResource,
                    method: "POST",
                    contentType: "application/json; charset=utf-8",
                    data: JSON.stringify(data),
                    headers: headers
                };
            };
            this.setupApplePay = function () {
                return ApplePaySession.openPaymentSetup(_this.merchantIdentifier)
                    .then(function (success) {
                    if (success) {
                        _this.hideSetupButton();
                        _this.showButton();
                    }
                    else {
                        _this.showError("Failed to set up Apple Pay.");
                    }
                    return success;
                }).catch(function (err) {
                    _this.showError("Failed to set up Apple Pay. " + JSON.stringify(err));
                    return false;
                });
            };
            this.showButton = function () {
                var button = $("#apple-pay-button");
                button.attr("lang", _this.getPageLanguage());
                button.on("click", _this.beginPayment);
                if (_this.supportsSetup()) {
                    button.addClass("apple-pay-button-with-text");
                    button.addClass("apple-pay-button-black-with-text");
                }
                else {
                    button.addClass("apple-pay-button");
                    button.addClass("apple-pay-button-black");
                }
                button.removeClass("hide");
            };
            this.showSetupButton = function () {
                var button = $("#set-up-apple-pay-button");
                button.attr("lang", _this.getPageLanguage());
                button.on("click", _this.setupApplePay);
                button.removeClass("hide");
            };
            this.updatePanel = function (panel, contact) {
                if (contact.emailAddress) {
                    panel.find(".contact-email")
                        .text(contact.emailAddress)
                        .attr("href", "mailto:" + contact.emailAddress)
                        .append("<br/>")
                        .removeClass("hide");
                }
                if (contact.emailAddress) {
                    panel.find(".contact-telephone")
                        .text(contact.phoneNumber)
                        .attr("href", "tel:" + contact.phoneNumber)
                        .append("<br/>")
                        .removeClass("hide");
                }
                if (contact.givenName) {
                    panel.find(".contact-name")
                        .text(contact.givenName + " " + contact.familyName)
                        .append("<br/>")
                        .removeClass("hide");
                }
                if (contact.addressLines) {
                    panel.find(".contact-address-lines").text(contact.addressLines.join(", "));
                    panel.find(".contact-locality").text(contact.locality);
                    panel.find(".contact-administrative-area").text(contact.administrativeArea);
                    panel.find(".contact-postal-code").text(contact.postalCode);
                    panel.find(".contact-country").text(contact.country);
                    panel.find(".contact-address").removeClass("hide");
                }
            };
            this.merchantIdentifier = $("meta[name='apple-pay-merchant-id']").attr("content");
            this.storeName = $("meta[name='apple-pay-store-name']").attr("content");
            this.validationResource = $("link[rel='merchant-validation']").attr("href");
            this.applePayVersion = 2;
            this.countryCode = $("meta[name='payment-country-code']").attr("content") || "GB";
            this.currencyCode = $("meta[name='payment-currency-code']").attr("content") || "GBP";
        }
        ApplePay.prototype.initialize = function () {
            var _this = this;
            if (!this.merchantIdentifier) {
                this.showError("No Apple Pay merchant certificate is configured.");
            }
            else if (this.supportedByDevice() === true) {
                if (this.canMakePayments() === true) {
                    this.showButton();
                }
                else {
                    this.canMakePaymentsWithActiveCard().then(function (canMakePayments) {
                        if (canMakePayments === true) {
                            _this.showButton();
                        }
                        else {
                            if (_this.supportsSetup()) {
                                _this.showSetupButton();
                            }
                            else {
                                _this.showError("Apple Pay cannot be used at this time. If using macOS Sierra you need to be paired with a device that supports TouchID.");
                            }
                        }
                    });
                }
            }
            else {
                this.showError("This device and/or browser does not support Apple Pay.");
            }
        };
        ApplePay.prototype.captureFunds = function (token) {
            return ApplePaySession.STATUS_SUCCESS;
        };
        ApplePay.prototype.canMakePayments = function () {
            return ApplePaySession.canMakePayments();
        };
        ApplePay.prototype.canMakePaymentsWithActiveCard = function () {
            return ApplePaySession.canMakePaymentsWithActiveCard(this.merchantIdentifier);
        };
        ApplePay.prototype.getPageLanguage = function () {
            return $("html").attr("lang") || "en";
        };
        ApplePay.prototype.hideSetupButton = function () {
            var button = $("#set-up-apple-pay-button");
            button.addClass("hide");
            button.off("click");
        };
        ApplePay.prototype.createValidationHeaders = function () {
            var headers = {};
            var antiforgeryHeader = $("meta[name='x-antiforgery-name']").attr("content");
            var antiforgeryToken = $("meta[name='x-antiforgery-token']").attr("content");
            headers[antiforgeryHeader] = antiforgeryToken;
            return headers;
        };
        ApplePay.prototype.showError = function (text) {
            var error = $(".apple-pay-error");
            error.text(text);
            error.removeClass("hide");
        };
        ApplePay.prototype.showSuccess = function () {
            $(".apple-pay-intro").hide();
            var success = $(".apple-pay-success");
            success.removeClass("hide");
        };
        ApplePay.prototype.supportedByDevice = function () {
            return "ApplePaySession" in window && ApplePaySession !== undefined;
        };
        ApplePay.prototype.supportsSetup = function () {
            return "openPaymentSetup" in ApplePaySession;
        };
        return ApplePay;
    }());
    justEat.ApplePay = ApplePay;
})(justEat || (justEat = {}));
(function () {
    var handler = new justEat.ApplePay();
    handler.initialize();
})();
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2l0ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInNpdGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0EsSUFBVSxPQUFPLENBMGFoQjtBQTFhRCxXQUFVLE9BQU87SUFLYjtRQWNJO1lBQUEsaUJBZUM7WUEwQ08saUJBQVksR0FBRyxVQUFDLENBQW9CO2dCQUV4QyxDQUFDLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBSW5CLElBQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDcEMsSUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDO2dCQUN4QixJQUFNLGFBQWEsR0FBRyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsR0FBRyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBRWpGLElBQU0sa0JBQWtCLEdBQUc7b0JBQ3ZCLEtBQUssRUFBRSxLQUFJLENBQUMsU0FBUztvQkFDckIsTUFBTSxFQUFFLFFBQVE7aUJBQ25CLENBQUM7Z0JBRUYsSUFBTSxzQkFBc0IsR0FBRztvQkFDM0IsRUFBRSxLQUFLLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLE9BQU8sRUFBRTtpQkFDekQsQ0FBQztnQkFFRixJQUFNLGdCQUFnQixHQUFHO29CQUNyQixLQUFLLEVBQUUsS0FBSSxDQUFDLFNBQVM7b0JBQ3JCLE1BQU0sRUFBRSxhQUFhO2lCQUN4QixDQUFDO2dCQUVGLElBQU0sb0JBQW9CLEdBQUc7b0JBQ3pCLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUU7b0JBQ3RELEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUU7aUJBQ3pELENBQUM7Z0JBR0YsSUFBTSxjQUFjLEdBQUcsS0FBSSxDQUFDLG9CQUFvQixDQUFDLFFBQVEsRUFBRSxvQkFBb0IsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUduRyxLQUFJLENBQUMsT0FBTyxHQUFHLElBQUksZUFBZSxDQUFDLEtBQUksQ0FBQyxlQUFlLEVBQUUsY0FBYyxDQUFDLENBQUM7Z0JBR3pFLEtBQUksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLEdBQUcsS0FBSSxDQUFDLGtCQUFrQixDQUFDO2dCQUcxRCxLQUFJLENBQUMsT0FBTyxDQUFDLHdCQUF3QixHQUFHLFVBQUMsS0FBSztvQkFFMUMsSUFBSSxRQUFRLENBQUM7b0JBQ2IsSUFBSSxZQUFZLENBQUM7b0JBR2pCLEVBQUUsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsVUFBVSxLQUFLLFlBQVksQ0FBQyxDQUFDLENBQUM7d0JBQ25ELFFBQVEsR0FBRyxrQkFBa0IsQ0FBQzt3QkFDOUIsWUFBWSxHQUFHLHNCQUFzQixDQUFDO29CQUMxQyxDQUFDO29CQUNELElBQUksQ0FBQyxDQUFDO3dCQUNGLFFBQVEsR0FBRyxnQkFBZ0IsQ0FBQzt3QkFDNUIsWUFBWSxHQUFHLG9CQUFvQixDQUFDO29CQUN4QyxDQUFDO29CQUVELEtBQUksQ0FBQyxPQUFPLENBQUMsK0JBQStCLENBQUMsZUFBZSxDQUFDLGNBQWMsRUFBRSxRQUFRLEVBQUUsWUFBWSxDQUFDLENBQUM7Z0JBQ3pHLENBQUMsQ0FBQztnQkFHRixLQUFJLENBQUMsT0FBTyxDQUFDLG1CQUFtQixHQUFHLEtBQUksQ0FBQyxtQkFBbUIsQ0FBQztnQkFHNUQsS0FBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUN6QixDQUFDLENBQUE7WUFzQ08seUJBQW9CLEdBQUcsVUFBQyxjQUFzQixFQUFFLFNBQXdDLEVBQUUsS0FBa0M7Z0JBQ2hJLE1BQU0sQ0FBQztvQkFDSCxXQUFXLEVBQUUsS0FBSSxDQUFDLFdBQVc7b0JBQzdCLFlBQVksRUFBRSxLQUFJLENBQUMsWUFBWTtvQkFDL0Isb0JBQW9CLEVBQUUsQ0FBQyxhQUFhLEVBQUUsZ0JBQWdCLEVBQUUsZUFBZSxDQUFDO29CQUN4RSxpQkFBaUIsRUFBRSxDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxjQUFjLEVBQUUsTUFBTSxDQUFDO29CQUNwRixTQUFTLEVBQUUsU0FBUztvQkFDcEIsS0FBSyxFQUFFLEtBQUs7b0JBQ1osNEJBQTRCLEVBQUUsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxlQUFlLENBQUM7b0JBQ3pFLDZCQUE2QixFQUFFLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsZUFBZSxDQUFDO29CQUMxRSxZQUFZLEVBQUUsVUFBVTtvQkFDeEIsZUFBZSxFQUFFO3dCQUNiLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsY0FBYyxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLGlCQUFpQixFQUFFO3dCQUNoRyxFQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSx3QkFBd0IsRUFBRTtxQkFDdEc7aUJBQ0osQ0FBQztZQUNOLENBQUMsQ0FBQTtZQXVCTyx3QkFBbUIsR0FBRyxVQUFDLEtBQWdEO2dCQUkzRSxJQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztnQkFHbEMsSUFBTSxhQUFhLEdBQUcsS0FBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFFL0MsRUFBRSxDQUFDLENBQUMsYUFBYSxLQUFLLGVBQWUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDO29CQUluRCxJQUFNLGNBQWMsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQztvQkFDcEQsSUFBTSxlQUFlLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUM7b0JBR3RELENBQUMsQ0FBQyxZQUFZLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUFDO29CQUNwRSxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLGNBQWMsQ0FBQyxDQUFDO29CQUN4RCxLQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFLGVBQWUsQ0FBQyxDQUFDO29CQUUxRCxLQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxhQUFhLENBQUMsQ0FBQztvQkFDNUMsS0FBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUN2QixDQUFDO2dCQUNELElBQUksQ0FBQyxDQUFDO29CQUNGLEtBQUksQ0FBQyxTQUFTLENBQUMsc0RBQW9ELGFBQWEsTUFBRyxDQUFDLENBQUM7Z0JBQ3pGLENBQUM7WUFDTCxDQUFDLENBQUE7WUFNTyx1QkFBa0IsR0FBRyxVQUFDLEtBQStDO2dCQUd6RSxJQUFNLElBQUksR0FBRztvQkFDVCxhQUFhLEVBQUUsS0FBSyxDQUFDLGFBQWE7aUJBQ3JDLENBQUM7Z0JBRUYsSUFBTSxPQUFPLEdBQUcsS0FBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7Z0JBQy9DLElBQU0sT0FBTyxHQUFHLEtBQUksQ0FBQyx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBSTVELENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsZUFBZTtvQkFFakMsS0FBSSxDQUFDLE9BQU8sQ0FBQywwQkFBMEIsQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFDN0QsQ0FBQyxDQUFDLENBQUM7WUFDUCxDQUFDLENBQUE7WUEwQk8sNEJBQXVCLEdBQUcsVUFBQyxJQUFTLEVBQUUsT0FBWTtnQkFDdEQsTUFBTSxDQUFDO29CQUNILEdBQUcsRUFBRSxLQUFJLENBQUMsa0JBQWtCO29CQUM1QixNQUFNLEVBQUUsTUFBTTtvQkFDZCxXQUFXLEVBQUUsaUNBQWlDO29CQUM5QyxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7b0JBQzFCLE9BQU8sRUFBRSxPQUFPO2lCQUNuQixDQUFDO1lBQ04sQ0FBQyxDQUFBO1lBS08sa0JBQWEsR0FBRztnQkFDcEIsTUFBTSxDQUFDLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFJLENBQUMsa0JBQWtCLENBQUM7cUJBQzNELElBQUksQ0FBQyxVQUFDLE9BQU87b0JBQ1YsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzt3QkFDVixLQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7d0JBQ3ZCLEtBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztvQkFDdEIsQ0FBQztvQkFDRCxJQUFJLENBQUMsQ0FBQzt3QkFDRixLQUFJLENBQUMsU0FBUyxDQUFDLDZCQUE2QixDQUFDLENBQUM7b0JBQ2xELENBQUM7b0JBQ0QsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFDbkIsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQUMsR0FBUTtvQkFDZCxLQUFJLENBQUMsU0FBUyxDQUFDLGlDQUErQixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBRyxDQUFDLENBQUM7b0JBQ3JFLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0JBQ2pCLENBQUMsQ0FBQyxDQUFDO1lBQ1gsQ0FBQyxDQUFBO1lBS08sZUFBVSxHQUFHO2dCQUVqQixJQUFNLE1BQU0sR0FBRyxDQUFDLENBQUMsbUJBQW1CLENBQUMsQ0FBQztnQkFDdEMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7Z0JBQzVDLE1BQU0sQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLEtBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFFdEMsRUFBRSxDQUFDLENBQUMsS0FBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDdkIsTUFBTSxDQUFDLFFBQVEsQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO29CQUM5QyxNQUFNLENBQUMsUUFBUSxDQUFDLGtDQUFrQyxDQUFDLENBQUM7Z0JBQ3hELENBQUM7Z0JBQ0QsSUFBSSxDQUFDLENBQUM7b0JBQ0YsTUFBTSxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO29CQUNwQyxNQUFNLENBQUMsUUFBUSxDQUFDLHdCQUF3QixDQUFDLENBQUM7Z0JBQzlDLENBQUM7Z0JBRUQsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUMvQixDQUFDLENBQUE7WUFlTyxvQkFBZSxHQUFHO2dCQUN0QixJQUFNLE1BQU0sR0FBRyxDQUFDLENBQUMsMEJBQTBCLENBQUMsQ0FBQztnQkFDN0MsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7Z0JBQzVDLE1BQU0sQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLEtBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztnQkFDdkMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUMvQixDQUFDLENBQUE7WUFnQ08sZ0JBQVcsR0FBRyxVQUFDLEtBQWEsRUFBRSxPQUEwQztnQkFFNUUsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7b0JBQ3ZCLEtBQUssQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7eUJBQ3ZCLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDO3lCQUMxQixJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDO3lCQUM5QyxNQUFNLENBQUMsT0FBTyxDQUFDO3lCQUNmLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDN0IsQ0FBQztnQkFFRCxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztvQkFDdkIsS0FBSyxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQzt5QkFDM0IsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUM7eUJBQ3pCLElBQUksQ0FBQyxNQUFNLEVBQUUsTUFBTSxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUM7eUJBQzFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7eUJBQ2YsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUM3QixDQUFDO2dCQUVELEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUNwQixLQUFLLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQzt5QkFDdEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsR0FBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUM7eUJBQ2xELE1BQU0sQ0FBQyxPQUFPLENBQUM7eUJBQ2YsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUM3QixDQUFDO2dCQUVELEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO29CQUN2QixLQUFLLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBQzNFLEtBQUssQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUN2RCxLQUFLLENBQUMsSUFBSSxDQUFDLDhCQUE4QixDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO29CQUM1RSxLQUFLLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztvQkFDNUQsS0FBSyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7b0JBQ3JELEtBQUssQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3ZELENBQUM7WUFDTCxDQUFDLENBQUE7WUFsWkcsSUFBSSxDQUFDLGtCQUFrQixHQUFHLENBQUMsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUNsRixJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUd4RSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLGlDQUFpQyxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBRzVFLElBQUksQ0FBQyxlQUFlLEdBQUcsQ0FBQyxDQUFDO1lBR3pCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLG1DQUFtQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLElBQUksQ0FBQztZQUNsRixJQUFJLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxLQUFLLENBQUM7UUFDekYsQ0FBQztRQUtNLDZCQUFVLEdBQWpCO1lBQUEsaUJBK0JDO1lBN0JHLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQztnQkFDM0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxrREFBa0QsQ0FBQyxDQUFDO1lBQ3ZFLENBQUM7WUFFRCxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQztnQkFJekMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7b0JBQ2xDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDdEIsQ0FBQztnQkFDRCxJQUFJLENBQUMsQ0FBQztvQkFDRixJQUFJLENBQUMsNkJBQTZCLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBQyxlQUFlO3dCQUN0RCxFQUFFLENBQUMsQ0FBQyxlQUFlLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQzs0QkFDM0IsS0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO3dCQUN0QixDQUFDO3dCQUNELElBQUksQ0FBQyxDQUFDOzRCQUNGLEVBQUUsQ0FBQyxDQUFDLEtBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0NBQ3ZCLEtBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQzs0QkFDM0IsQ0FBQzs0QkFBQyxJQUFJLENBQUMsQ0FBQztnQ0FDSixLQUFJLENBQUMsU0FBUyxDQUFDLHlIQUF5SCxDQUFDLENBQUM7NEJBQzlJLENBQUM7d0JBQ0wsQ0FBQztvQkFDTCxDQUFDLENBQUMsQ0FBQztnQkFDUCxDQUFDO1lBQ0wsQ0FBQztZQUNELElBQUksQ0FBQyxDQUFDO2dCQUNGLElBQUksQ0FBQyxTQUFTLENBQUMsd0RBQXdELENBQUMsQ0FBQztZQUM3RSxDQUFDO1FBQ0wsQ0FBQztRQTJFTywrQkFBWSxHQUFwQixVQUFxQixLQUFzQztZQUt2RCxNQUFNLENBQUMsZUFBZSxDQUFDLGNBQWMsQ0FBQztRQUMxQyxDQUFDO1FBTU8sa0NBQWUsR0FBdkI7WUFDSSxNQUFNLENBQUMsZUFBZSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQzdDLENBQUM7UUFNTyxnREFBNkIsR0FBckM7WUFDSSxNQUFNLENBQUMsZUFBZSxDQUFDLDZCQUE2QixDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1FBQ2xGLENBQUM7UUErQk8sa0NBQWUsR0FBdkI7WUFDSSxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUM7UUFDMUMsQ0FBQztRQUtPLGtDQUFlLEdBQXZCO1lBQ0ksSUFBTSxNQUFNLEdBQUcsQ0FBQyxDQUFDLDBCQUEwQixDQUFDLENBQUM7WUFDN0MsTUFBTSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN4QixNQUFNLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3hCLENBQUM7UUE2RE8sMENBQXVCLEdBQS9CO1lBR0ksSUFBSSxPQUFPLEdBQVEsRUFDbEIsQ0FBQztZQUdGLElBQU0saUJBQWlCLEdBQUcsQ0FBQyxDQUFDLGlDQUFpQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQy9FLElBQU0sZ0JBQWdCLEdBQUcsQ0FBQyxDQUFDLGtDQUFrQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRS9FLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLGdCQUFnQixDQUFDO1lBRTlDLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFDbkIsQ0FBQztRQThETyw0QkFBUyxHQUFqQixVQUFrQixJQUFZO1lBQzFCLElBQU0sS0FBSyxHQUFHLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQ3BDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDakIsS0FBSyxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM5QixDQUFDO1FBZU8sOEJBQVcsR0FBbkI7WUFDSSxDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUM3QixJQUFNLE9BQU8sR0FBRyxDQUFDLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUN4QyxPQUFPLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2hDLENBQUM7UUFNTyxvQ0FBaUIsR0FBekI7WUFDSSxNQUFNLENBQUMsaUJBQWlCLElBQUksTUFBTSxJQUFJLGVBQWUsS0FBSyxTQUFTLENBQUM7UUFDeEUsQ0FBQztRQU1PLGdDQUFhLEdBQXJCO1lBQ0ksTUFBTSxDQUFDLGtCQUFrQixJQUFJLGVBQWUsQ0FBQztRQUNqRCxDQUFDO1FBeUNMLGVBQUM7SUFBRCxDQUFDLEFBcGFELElBb2FDO0lBcGFZLGdCQUFRLFdBb2FwQixDQUFBO0FBQ0wsQ0FBQyxFQTFhUyxPQUFPLEtBQVAsT0FBTyxRQTBhaEI7QUFFRCxDQUFDO0lBQ0csSUFBTSxPQUFPLEdBQUcsSUFBSSxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDdkMsT0FBTyxDQUFDLFVBQVUsRUFBRSxDQUFDO0FBQ3pCLENBQUMsQ0FBQyxFQUFFLENBQUMifQ==